﻿namespace BookVerse.GCommon;

public static class SeedingConstants
{
    public const string DefaultUserId = "df1c3a0f-1234-4cde-bb55-d5f15a6aabcd";
}